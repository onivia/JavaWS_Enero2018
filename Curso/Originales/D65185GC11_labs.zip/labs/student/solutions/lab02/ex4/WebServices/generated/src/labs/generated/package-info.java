@javax.xml.bind.annotation.XmlSchema(namespace = "urn://Auction/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package labs.generated;
