package Services;

import Model.BiddingListener; 

/**
 *
 * @author education@oracle.com
 */
public class NotificationService {

  /**
   *
   */
  public NotificationService () {
  }

  /**
   *
   * @param l
   */
  public void registerInterest (BiddingListener l) {
  }
}

