package Services;

/**
 *
 * @author education@oracle.com
 */
public interface BiddingListener {

  /**
   *
   * @param Unnamed
   */
  public void bidPlaced (BiddingEventTO Unnamed);
}

