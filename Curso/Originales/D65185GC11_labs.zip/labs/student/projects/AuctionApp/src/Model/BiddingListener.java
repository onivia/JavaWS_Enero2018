package Model;

/**
 *
 * @author education@oracle.com
 */
public interface BiddingListener {

  /**
   *
   * @param event
   */
  public void bidPlaced (BiddingEvent event);
}

