package Services;

/**
 *
 * @author education@oracle.com
 */
public class BiddingEventTO {

  /**
   *
   */
  public BiddingEventTO () {
  }
}

