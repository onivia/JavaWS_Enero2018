@javax.xml.bind.annotation.XmlSchema(namespace = "urn://Traveller", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package traveller;
